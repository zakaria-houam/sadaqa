<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php $__currentLoopData = $postes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col">
    <div class="card" style="width: 18rem;">
  <img src="./postesimage/<?php echo e($postes->image); ?>" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title"><?php echo e($postes->title); ?></h5>
    <p class="card-text"><?php echo e($postes->description); ?></p>
    <a href="<?php echo e($postes->link); ?>" class="btn full">اقرأ المنشور كاملا</a>
  </div>
</div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  


<?php /**PATH D:\ZAKI\Dev Web\sadaqa jaria\sadaqa_jaria\resources\views/postes.blade.php ENDPATH**/ ?>