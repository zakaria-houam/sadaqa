<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

<div class="admin-home">
    <h1 class="admin-title">إدارة صفحة الكتب</h1>

    <form action="<?php echo e(url('uploadbook')); ?>" method="post" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
  <div class="mb-3">
    <label for="booktitle" class="form-label">عنوان الكتاب</label>
    <input type="text" class="form-control" id="booktitle" aria-describedby="emailHelp" name="title" required>
    
  </div>
  <div class="mb-3">
    <label for="description" class="form-label">وصف الكتاب</label>
    <input type="text" class="form-control" id="description" name="description" required>
  </div>
  <div class="mb-3">
    <label for="link" class="form-label"> رابط التجميل</label>
    <input type="text" class="form-control" id="link" name="link" required>
  </div>
  <div class="mb-3">
    <label for="image" class="form-label">  غلاف الكتاب</label>
    <input type="file" class="form-control" id="image" accept="image/png, image/gif, image/jpeg" name="image" required>
  </div>
  <button type="submit" class="btn">أضف الكتاب</button>
</form>

<h1 class="admin-title">الكتب الموجودة حاليا</h1>

<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">العنوان</th>
      <th scope="col">الوصف</th>
      <th scope="col">الحالة</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($data->id); ?></th>
      <td><?php echo e($data->title); ?></td>
      <td><?php echo e($data->description); ?></td>
      <td><a href="<?php echo e(url('/deletebook',$data->id)); ?>">حذف الكتاب</a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>




<h1 class="admin-title">إدارة صفحة المنشورات</h1>

    <form action="<?php echo e(url('uploadpostes')); ?>" method="post" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
  <div class="mb-3">
    <label for="booktitle" class="form-label">عنوان المنشور</label>
    <input type="text" class="form-control" id="booktitle" aria-describedby="emailHelp" name="title" required>
    
  </div>
  <div class="mb-3">
    <label for="description" class="form-label">وصف المنشور</label>
    <input type="text" class="form-control" id="description" name="description" required>
  </div>
  <div class="mb-3">
    <label for="link" class="form-label"> رابط المنشور</label>
    <input type="text" class="form-control" id="link" name="link" required>
  </div>
  <div class="mb-3">
    <label for="image" class="form-label">  غلاف المنشور</label>
    <input type="file" class="form-control" id="image" accept="image/png, image/gif, image/jpeg" name="image" required>
  </div>
  <button type="submit" class="btn">أضف المنشور</button>
</form>

<h1 class="admin-title">المنشورات الموجودة حاليا</h1>

<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">العنوان</th>
      <th scope="col">الوصف</th>
      <th scope="col">الحالة</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $postes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($postes->id); ?></th>
      <td><?php echo e($postes->title); ?></td>
      <td><?php echo e($postes->description); ?></td>
      <td><a href="<?php echo e(url('/deletpostes',$postes->id)); ?>">حذف المنشور</a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>







   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
     <script src="./assets/js.js"></script>
</body>
</html>
<?php /**PATH D:\ZAKI\Dev Web\sadaqa jaria\sadaqa_jaria\resources\views/admin.blade.php ENDPATH**/ ?>